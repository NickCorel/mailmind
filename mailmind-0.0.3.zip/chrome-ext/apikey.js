const apiKeyIcon = document.querySelector(".apikey-icon");
const apiKeyBox = document.querySelector("#apiKey").parentElement;
const apiKeyPage = document.querySelector(".apikey-page");
const closeIcon = document.querySelector(".close-icon");
const apiKey = document.getElementById("apiKey");

apiKeyIcon.addEventListener("click", function() {
    apiKeyPage.classList.add("active");
    
    // Check if the API Key has been saved in local storage
    if (localStorage.getItem("apiKey")) {
        apiKey.value = localStorage.getItem("apiKey");
        }
});

closeIcon.addEventListener("click", function() {
    apiKeyPage.classList.remove("active");

    // Save the API Key to local storage
    localStorage.setItem("apiKey", apiKey.value);
});